import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

CSV_PATH = "data/historical_power_consumption.csv"

# 1) Load data
df = pd.read_csv(CSV_PATH, parse_dates=["timestamp"])
df = df.sort_values("timestamp").reset_index(drop=True)

# 2) Split into baseline (past) and current (new)
#    baseline = first 70%, current = last 30%
split_idx = int(len(df) * 0.7)
baseline = df.iloc[:split_idx].copy()
current = df.iloc[split_idx:].copy()

# ---- ADD DRIFT HERE ----
current["voltage"] = current["voltage"] + 8
current["global_active_power"] = current["global_active_power"] * 1.25


# 3) Simple drift score per feature (difference in mean / baseline std)
features = ["voltage", "global_active_power", "global_reactive_power", "intensity"]

results = []
for col in features:
    b_mean = baseline[col].mean()
    b_std = baseline[col].std() if baseline[col].std() > 0 else 1e-9
    c_mean = current[col].mean()

    drift_score = abs(c_mean - b_mean) / b_std  # z-like score
    results.append((col, b_mean, c_mean, b_std, drift_score))

res_df = pd.DataFrame(results, columns=["feature", "baseline_mean", "current_mean", "baseline_std", "drift_score"])
print("\n=== Drift summary (simple) ===")
print(res_df.sort_values("drift_score", ascending=False).to_string(index=False))

# 4) Plot distributions (baseline vs current) for each feature
import os
os.makedirs("G7_drift_analysis/outputs", exist_ok=True)

for col in features:
    plt.figure()
    plt.hist(baseline[col].dropna(), bins=40, alpha=0.6, label="baseline")
    plt.hist(current[col].dropna(), bins=40, alpha=0.6, label="current")
    plt.title(f"Distribution: {col} (baseline vs current)")
    plt.legend()

    out_path = f"outputs/hist_{col}.png"
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()

from scipy.stats import ks_2samp

print("\n=== KS Test (baseline vs current) ===")

for col in features:
    stat, p_value = ks_2samp(
        baseline[col].dropna(),
        current[col].dropna()
    )

    print(f"{col:25s} | KS stat = {stat:.4f} | p-value = {p_value:.4e}")
