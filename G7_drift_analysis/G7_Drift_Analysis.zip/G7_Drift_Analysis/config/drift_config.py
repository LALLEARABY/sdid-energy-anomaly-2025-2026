"""
Configuration pour l'analyse de dérive (Drift Analysis) - Groupe 7
"""

import os
from datetime import timedelta

# ============================================================================
# CONFIGURATION BASE DE DONNÉES (depuis G2)
# ============================================================================
DB_CONFIG = {
    "host": os.getenv("POSTGRES_HOST", "127.0.0.1"),
    "port": int(os.getenv("POSTGRES_PORT", 5433)),
    "dbname": os.getenv("POSTGRES_DB", "sdid_db"),
    "user": os.getenv("POSTGRES_USER", "sdid_user"),
    "password": os.getenv("POSTGRES_PASSWORD", "sdid_password"),
}

# ============================================================================
# CONFIGURATION BASELINE (Profil de Référence)
# ============================================================================
BASELINE_CONFIG = {
    # Nombre de lignes pour créer la baseline
    "sample_size": 10000,
    
    # Période de référence (premiers jours de données)
    "reference_period_days": 7,
    
    # Fenêtre glissante pour comparaison (en jours)
    "window_size_days": 1,
    
    # Chemin de sauvegarde
    "save_path": "data/baseline/",
}

# ============================================================================
# CONFIGURATION TESTS STATISTIQUES
# ============================================================================
STATISTICAL_TESTS_CONFIG = {
    # Test de Kolmogorov-Smirnov
    "ks_test": {
        "alpha": 0.05,  # Seuil de significativité
        "alert_threshold": 0.10,  # p-value < 0.10 = alerte
    },
    
    # Population Stability Index (PSI)
    "psi": {
        "bins": 10,  # Nombre de bins pour discrétisation
        "alert_threshold": 0.1,  # PSI < 0.1 = pas de drift
        "warning_threshold": 0.25,  # 0.1 < PSI < 0.25 = drift modéré
        # PSI > 0.25 = drift significatif
    },
    
    # Jensen-Shannon Divergence
    "js_divergence": {
        "alert_threshold": 0.15,
    },
}

# ============================================================================
# CONFIGURATION DÉTECTION DE DÉRIVE
# ============================================================================
DRIFT_DETECTION_CONFIG = {
    # Fréquence de vérification (en heures)
    "check_frequency_hours": 6,
    
    # Fenêtre d'observation (combien d'heures de données comparer)
    "observation_window_hours": 24,
    
    # Colonnes à surveiller pour Data Drift
    "monitored_columns": [
        "global_active_power",
        "global_reactive_power",
        "voltage",
        "global_intensity",
    ],
    
    # Seuils de dérive
    "data_drift_threshold": 0.15,  # % de changement acceptable
    "concept_drift_threshold": 0.20,
    
    # Chemin de sauvegarde des alertes
    "alerts_path": "data/monitoring/alerts.json",
}

# ============================================================================
# CONFIGURATION MESURE PERFORMANCE MODÈLES
# ============================================================================
MODEL_PERFORMANCE_CONFIG = {
    # Métriques pour G3 (Clustering)
    "g3_metrics": {
        "silhouette_threshold": 0.3,  # Score silhouette minimum acceptable
        "cluster_stability_threshold": 0.85,  # % de stabilité requis
    },
    
    # Métriques pour G4 (Anomaly Detection)
    "g4_metrics": {
        "precision_threshold": 0.80,  # Précision minimum
        "recall_threshold": 0.75,  # Rappel minimum
        "f1_threshold": 0.77,  # F1-score minimum
        "false_positive_rate_max": 0.15,  # Taux FP maximum acceptable
    },
    
    # Fréquence d'évaluation (en jours)
    "evaluation_frequency_days": 7,
    
    # Chemin de sauvegarde des métriques
    "metrics_path": "data/monitoring/model_metrics.json",
}

# ============================================================================
# CONFIGURATION IMPACT ÉCONOMIQUE
# ============================================================================
ECONOMIC_IMPACT_CONFIG = {
    # Coûts (en euros)
    "cost_false_positive": 50,  # Coût d'une fausse alerte
    "cost_false_negative": 500,  # Coût d'une anomalie manquée
    "cost_true_positive": -100,  # Gain d'une détection correcte
    "cost_maintenance_hour": 150,  # Coût horaire maintenance système
    
    # Fréquence de calcul ROI
    "roi_calculation_frequency_days": 30,
    
    # Chemin de sauvegarde
    "economic_reports_path": "reports/economic_impact/",
}

# ============================================================================
# CONFIGURATION STRATÉGIE RÉ-ENTRAÎNEMENT
# ============================================================================
RETRAINING_STRATEGY_CONFIG = {
    # Seuils déclencheurs ré-entraînement
    "triggers": {
        "psi_threshold": 0.25,  # PSI > 0.25 = ré-entraînement obligatoire
        "performance_drop_threshold": 0.10,  # Baisse > 10% = ré-entraînement
        "drift_duration_days": 3,  # Drift persistant > 3 jours
        "anomaly_rate_change": 0.20,  # Changement > 20% taux anomalies
    },
    
    # Paramètres ré-entraînement
    "retraining": {
        "min_data_size": 5000,  # Minimum de nouvelles données
        "validation_split": 0.2,  # 20% pour validation
        "rolling_window_days": 30,  # Fenêtre glissante pour nouvelles données
    },
    
    # Fréquence de vérification (en jours)
    "check_frequency_days": 7,
    
    # Chemin de sauvegarde logs
    "retraining_logs_path": "data/monitoring/retraining_logs.json",
}

# ============================================================================
# CHEMINS DES ARTÉFACTS G3 (Data Mining)
# ============================================================================
G3_ARTIFACTS_PATHS = {
    "scaler": "../G3_data_mining/artifacts/scaler.pkl",
    "pca": "../G3_data_mining/artifacts/pca.pkl",
    "clusters": "../G3_data_mining/artifacts/clusters.json",
    "dbscan_params": "../G3_data_mining/artifacts/dbscan_params.json",
}

# ============================================================================
# CHEMINS DES ARTÉFACTS G4 (Anomaly Detection)
# ============================================================================
G4_ARTIFACTS_PATHS = {
    "isolation_forest": "../G4_Anomaly_Detection/models/isolation_forest.pkl",
    "threshold": "../G4_Anomaly_Detection/config/threshold.json",
    "performance_stats": "../G4_Anomaly_Detection/reports/performance.json",
}

# ============================================================================
# CONFIGURATION VISUALISATIONS
# ============================================================================
VISUALIZATION_CONFIG = {
    # Style graphiques
    "style": "seaborn",
    "figsize": (12, 6),
    "dpi": 300,
    
    # Couleurs alertes
    "colors": {
        "normal": "#2ecc71",      # Vert
        "warning": "#f39c12",     # Orange
        "critical": "#e74c3c",    # Rouge
        "baseline": "#3498db",    # Bleu
    },
    
    # Chemin sauvegarde graphiques
    "output_path": "visualization/outputs/",
}

# ============================================================================
# CONFIGURATION LOGGING
# ============================================================================
LOGGING_CONFIG = {
    "level": "INFO",  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "log_file": "logs/drift_analysis.log",
}

# ============================================================================
# CONFIGURATION RAPPORTS
# ============================================================================
REPORTING_CONFIG = {
    # Format des rapports
    "format": "markdown",  # markdown, pdf, html
    
    # Fréquence génération rapport (en jours)
    "frequency_days": 7,
    
    # Chemin rapports
    "reports_path": "reports/",
    
    # Template rapport
    "template_path": "reports/templates/audit_template.md",
}

# ============================================================================
# FONCTIONS UTILITAIRES
# ============================================================================

def get_db_connection_string():
    """
    Retourne la chaîne de connexion PostgreSQL pour SQLAlchemy
    """
    return (
        f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}"
        f"@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['dbname']}"
    )

def get_baseline_path(filename):
    """
    Retourne le chemin complet pour un fichier baseline
    """
    import os
    os.makedirs(BASELINE_CONFIG["save_path"], exist_ok=True)
    return os.path.join(BASELINE_CONFIG["save_path"], filename)

def get_monitoring_path(filename):
    """
    Retourne le chemin complet pour un fichier de monitoring
    """
    import os
    os.makedirs("data/monitoring/", exist_ok=True)
    return os.path.join("data/monitoring/", filename)

# ============================================================================
# VALIDATION CONFIGURATION
# ============================================================================

def validate_config():
    """
    Valide la configuration au démarrage
    """
    errors = []
    
    # Vérifier que les seuils sont cohérents
    if STATISTICAL_TESTS_CONFIG["psi"]["alert_threshold"] >= \
       STATISTICAL_TESTS_CONFIG["psi"]["warning_threshold"]:
        errors.append("PSI alert_threshold doit être < warning_threshold")
    
    # Vérifier les chemins G3
    import os
    for name, path in G3_ARTIFACTS_PATHS.items():
        if not os.path.exists(path):
            errors.append(f"Artéfact G3 manquant : {name} ({path})")
    
    if errors:
        print("⚠  AVERTISSEMENTS DE CONFIGURATION :")
        for error in errors:
            print(f"  - {error}")
    else:
        print(" Configuration validée avec succès")
    
    return len(errors) == 0

if __name__ == "__main__":
    print("=== Configuration Groupe 7 - Drift Analysis ===")
    print(f"Base de données : {DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['dbname']}")
    print(f"Taille baseline : {BASELINE_CONFIG['sample_size']} lignes")
    print(f"Seuil PSI alerte : {STATISTICAL_TESTS_CONFIG['psi']['alert_threshold']}")
    print()
    validate_config()
