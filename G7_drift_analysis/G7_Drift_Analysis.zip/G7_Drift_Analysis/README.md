# 📊 G7 - Analyse de Dérive et Stratégie
## Drift Analysis & Strategy - SDID 2025/2026

[![Python](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/)
[![PostgreSQL](https://img.shields.io/badge/postgresql-13+-blue.svg)](https://www.postgresql.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

---

## 🎯 Objectif du Groupe

Le **Groupe 7** est responsable de l'**analyse de dérive (drift)** et de la **stratégie de maintenance** du système de détection d'anomalies énergétiques. Notre mission consiste à :

1. **Détecter les dérives** dans les distributions de données (Data Drift)
2. **Identifier les changements** de comportement (Concept Drift)
3. **Mesurer l'obsolescence** des modèles de G3 et G4
4. **Calculer l'impact économique** de la dégradation
5. **Définir une stratégie** de ré-entraînement automatisé
6. **Produire un audit stratégique** pour la maintenance long terme

---

## 📁 Structure du Projet

```
G7_drift_analysis/
│
├── config/
│   └── drift_config.py              # Configuration des seuils et paramètres
│
├── src/
│   ├── db_connector.py              # Connexion PostgreSQL (G2)
│   ├── baseline_builder.py          # Tâche 1: Profil de référence
│   ├── statistical_tests.py         # Tâche 2: Tests KS, PSI
│   ├── drift_detector.py            # Tâche 3: Détection drift
│   ├── model_performance.py         # Tâche 4: Obsolescence modèles
│   ├── economic_impact.py           # Tâche 5: Calcul ROI
│   └── retraining_strategy.py       # Tâche 6: Planification
│
├── data/
│   ├── baseline/                    # Données de référence
│   └── monitoring/                  # Logs de surveillance
│
├── visualization/
│   ├── drift_plots.py               # Génération graphiques
│   └── outputs/                     # Images exportées
│
├── reports/
│   └── audit_strategique.md         # Tâche 7: Rapport final
│
├── notebooks/
│   └── drift_analysis.ipynb         # Expérimentation
│
├── tests/
│   └── test_*.py                    # Tests unitaires
│
├── requirements.txt                 # Dépendances Python
└── README.md                        # Ce fichier
```

---

## 🔗 Dépendances entre Groupes

### Nous dépendons de :

#### **G2 - Data Engineering** 🟢 OPÉRATIONNEL
- **Base PostgreSQL** : `power_consumption` table
- **Données temps réel** : Flux continu d'ingestion
- **Connectivité** : Port 5433, credentials fournis

#### **G3 - Data Mining** 🟡 EN COURS
- **Artifacts** : `scaler.pkl`, `pca.pkl`, `clusters.json`
- **Paramètres** : Hyperparamètres DBSCAN
- **Documentation** : Dictionnaire de clusters

#### **G4 - Anomaly Detection** 🔴 EN ATTENTE
- **Modèle** : `isolation_forest.pkl`
- **Métriques** : Taux de précision, rappel
- **Seuils** : Threshold de détection

### Nous fournissons à :

#### **G1 - Coordination**
- Mini-rapport technique
- Graphiques de dérive
- Recommandations stratégiques

---

## 🚀 Installation

### 1. Prérequis

- Python 3.8+
- PostgreSQL en cours d'exécution (via docker-compose)
- Accès à la table `power_consumption`

### 2. Installation des dépendances

```bash
cd G7_drift_analysis
pip install -r requirements.txt
```

### 3. Configuration

Vérifier que la configuration est correcte :

```bash
python config/drift_config.py
```

### 4. Test de connexion

```bash
python src/db_connector.py
```

---

## 📊 Utilisation

### Étape 1 : Créer la Baseline

```bash
python src/baseline_builder.py
```

**Résultat :** Création de `data/baseline/` avec les statistiques de référence

### Étape 2 : Tests Statistiques

```python
from src.statistical_tests import StatisticalTests
from src.db_connector import get_connection

# Charger la baseline
tester = StatisticalTests()
tester.load_baseline("data/baseline/")

# Récupérer données récentes
db = get_connection()
recent_data = db.fetch_recent_data(hours=24)

# Exécuter les tests
results = tester.run_all_tests('global_active_power', recent_data['global_active_power'])
print(results)
```

### Étape 3 : Surveillance Continue

```bash
python src/drift_detector.py --monitor --interval 3600
```

**Options :**
- `--monitor` : Mode surveillance continue
- `--interval` : Fréquence de vérification (secondes)
- `--columns` : Colonnes à surveiller

---

## 🧪 Tests Statistiques Implémentés

### 1. Test de Kolmogorov-Smirnov (KS Test)

**Objectif :** Détecte si deux distributions sont différentes

**Interprétation :**
- p-value < 0.05 → Drift significatif
- p-value ≥ 0.05 → Pas de drift

### 2. Population Stability Index (PSI)

**Objectif :** Mesure la stabilité d'une variable

**Interprétation :**
- PSI < 0.1 → Stable
- 0.1 ≤ PSI < 0.25 → Dérive modérée
- PSI ≥ 0.25 → Dérive significative

### 3. Jensen-Shannon Divergence

**Objectif :** Mesure la similarité entre distributions

**Interprétation :**
- JS < 0.15 → Distributions similaires
- JS ≥ 0.15 → Distributions différentes

---

## 📈 Métriques de Performance

### Modèle G3 (Clustering)
- Silhouette Score
- Stabilité des clusters
- Cohésion intra-cluster

### Modèle G4 (Anomaly Detection)
- Précision (Precision)
- Rappel (Recall)
- F1-Score
- Taux de faux positifs/négatifs

---

## 💰 Impact Économique

### Coûts considérés

- **Faux positifs** : 50€ / alerte
- **Faux négatifs** : 500€ / anomalie manquée
- **Vraie détection** : -100€ (gain)
- **Maintenance** : 150€ / heure

### Calcul ROI

```
ROI = (Gains - Coûts) / Coûts × 100%
```

---

## 🔄 Stratégie de Ré-entraînement

### Déclencheurs automatiques

1. **PSI > 0.25** pendant 3 jours consécutifs
2. **Baisse de performance > 10%** (précision/rappel)
3. **Taux d'anomalies change > 20%**

### Pipeline de ré-entraînement

1. Validation des seuils déclencheurs
2. Extraction nouvelles données (30 jours glissants)
3. Nettoyage et préparation
4. Ré-entraînement modèles G3 et G4
5. Validation sur set de test
6. Déploiement si amélioration confirmée

---

## 📚 Documentation

### Rapports générés

- **Rapport quotidien** : Alertes de drift
- **Rapport hebdomadaire** : Métriques de performance
- **Rapport mensuel** : ROI et recommandations
- **Audit final** : Stratégie long terme

### Visualisations

- Évolution temporelle des distributions
- Graphiques PSI par variable
- Dashboard de performance modèles
- Courbes ROI cumulatif

---

## 🛠️ Développement

### Structure du code

Chaque module suit le pattern :
```python
class ModuleName:
    def __init__(self):
        # Initialisation
    
    def main_function(self):
        # Logique principale
    
    def _private_helper(self):
        # Fonctions privées
```

### Tests unitaires

```bash
pytest tests/
```

### Couverture de code

```bash
pytest --cov=src tests/
```

---

## 📝 Tâches et Responsabilités

| Tâche | Module | Statut | Responsable |
|-------|--------|--------|-------------|
| 1. Baseline | `baseline_builder.py` | ✅ Terminé | - |
| 2. Tests Stats | `statistical_tests.py` | ✅ Terminé | - |
| 3. Drift Detection | `drift_detector.py` | 🔨 En cours | - |
| 4. Performance | `model_performance.py` | 📋 À faire | - |
| 5. ROI | `economic_impact.py` | 📋 À faire | - |
| 6. Retraining | `retraining_strategy.py` | 📋 À faire | - |
| 7. Audit | `audit_strategique.md` | 📋 À faire | - |

---

## 🐛 Dépannage

### Problème : "Connection refused" PostgreSQL

**Solution :**
```bash
docker-compose up -d postgres
```

### Problème : "Baseline not found"

**Solution :**
```bash
python src/baseline_builder.py
```

### Problème : Artéfacts G3 manquants

**Solution temporaire :**
Travailler uniquement avec les données PostgreSQL en attendant G3

---

## 📞 Support

- **Issues GitHub** : Pour bugs et questions techniques
- **Réunions hebdomadaires** : Lundi 10h (avec G1)
- **Slack** : Canal #groupe-7

---

## 🎓 Membres du Groupe

| Nom | Rôle | Contribution principale |
|-----|------|------------------------|
| - | Coordinateur | Baseline & Tests |
| - | Développeur | Drift Detection |
| - | Analyste | Performance & ROI |
| - | Stratège | Retraining & Audit |

---

## 📅 Planning

### Semaines 1-2 : Fondations ✅
- Configuration environnement
- Baseline créée
- Tests statistiques implémentés

### Semaines 3-4 : Détection 🔨
- Drift detector en temps réel
- Mesure performance modèles

### Semaines 5-6 : Stratégie 📋
- Calcul ROI
- Stratégie ré-entraînement
- Rapport final

---

## 📄 Licence

Ce projet est développé dans le cadre du cours SDID 2025/2026.

---

## 🙏 Remerciements

- **G2** pour la base de données robuste
- **G3** pour les modèles de clustering
- **G4** pour la détection d'anomalies
- **G1** pour la coordination générale

---

**Date de création :** 01/02/2026  
**Version :** 1.0  
**Groupe :** G7 - Drift Analysis & Strategy
