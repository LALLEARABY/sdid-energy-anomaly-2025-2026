"""
Module de construction de la Baseline (Profil de Référence) - Groupe 7
Tâche 1 : Établissement du Profil de Référence
"""

import pandas as pd
import numpy as np
import json
import pickle
import os
import sys
import logging
from datetime import datetime
from pathlib import Path

# Imports locaux
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.db_connector import get_connection
from config.drift_config import BASELINE_CONFIG, get_baseline_path

# Configuration logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class BaselineBuilder:
    """
    Classe pour construire le profil de référence (baseline)
    """
    
    def __init__(self, sample_size=None):
        """
        Initialise le constructeur de baseline
        
        Args:
            sample_size (int): Nombre de lignes pour la baseline
        """
        self.sample_size = sample_size or BASELINE_CONFIG["sample_size"]
        self.baseline_data = None
        self.baseline_stats = {}
        
    def fetch_baseline_data(self):
        """
        Récupère les données pour créer la baseline depuis PostgreSQL
        
        Returns:
            pd.DataFrame: Données de référence
        """
        logger.info(f"📥 Récupération de {self.sample_size} lignes pour la baseline...")
        
        db = get_connection()
        try:
            self.baseline_data = db.fetch_baseline_data(limit=self.sample_size)
            
            if len(self.baseline_data) < self.sample_size:
                logger.warning(
                    f"⚠️  Seulement {len(self.baseline_data)} lignes disponibles "
                    f"(demandé : {self.sample_size})"
                )
            
            logger.info(f"✅ {len(self.baseline_data)} lignes récupérées")
            return self.baseline_data
            
        finally:
            db.close()
    
    def calculate_statistics(self):
        """
        Calcule les statistiques descriptives de la baseline
        
        Returns:
            dict: Statistiques par colonne
        """
        if self.baseline_data is None:
            raise ValueError("Aucune donnée baseline chargée. Appelez fetch_baseline_data() d'abord.")
        
        logger.info("📊 Calcul des statistiques de référence...")
        
        # Colonnes numériques à analyser
        numeric_cols = [
            'global_active_power',
            'global_reactive_power',
            'voltage',
            'global_intensity',
            'sub_metering_1',
            'sub_metering_2',
            'sub_metering_3'
        ]
        
        self.baseline_stats = {}
        
        for col in numeric_cols:
            if col in self.baseline_data.columns:
                data = self.baseline_data[col].dropna()
                
                self.baseline_stats[col] = {
                    # Statistiques centrales
                    'mean': float(data.mean()),
                    'median': float(data.median()),
                    'std': float(data.std()),
                    
                    # Quantiles
                    'min': float(data.min()),
                    'q1': float(data.quantile(0.25)),
                    'q3': float(data.quantile(0.75)),
                    'max': float(data.max()),
                    
                    # Distribution
                    'skewness': float(data.skew()),
                    'kurtosis': float(data.kurtosis()),
                    
                    # Données brutes pour tests statistiques
                    'values': data.values.tolist(),
                    
                    # Métadonnées
                    'count': int(len(data)),
                    'missing': int(self.baseline_data[col].isna().sum())
                }
        
        # Informations temporelles
        self.baseline_stats['temporal'] = {
            'start_date': str(self.baseline_data['timestamp'].min()),
            'end_date': str(self.baseline_data['timestamp'].max()),
            'duration_hours': float(
                (self.baseline_data['timestamp'].max() - 
                 self.baseline_data['timestamp'].min()).total_seconds() / 3600
            ),
            'sample_size': int(len(self.baseline_data))
        }
        
        logger.info("✅ Statistiques calculées pour toutes les colonnes")
        return self.baseline_stats
    
    def calculate_distribution_bins(self, n_bins=10):
        """
        Calcule les bins de distribution pour le PSI (Population Stability Index)
        
        Args:
            n_bins (int): Nombre de bins
            
        Returns:
            dict: Bins et proportions par colonne
        """
        logger.info(f"📊 Calcul des bins de distribution ({n_bins} bins)...")
        
        distributions = {}
        numeric_cols = [
            'global_active_power', 'global_reactive_power',
            'voltage', 'global_intensity'
        ]
        
        for col in numeric_cols:
            if col in self.baseline_data.columns:
                data = self.baseline_data[col].dropna()
                
                # Créer les bins
                counts, bin_edges = np.histogram(data, bins=n_bins)
                
                # Calculer les proportions
                proportions = counts / counts.sum()
                
                distributions[col] = {
                    'bin_edges': bin_edges.tolist(),
                    'counts': counts.tolist(),
                    'proportions': proportions.tolist()
                }
        
        self.baseline_stats['distributions'] = distributions
        logger.info("✅ Distributions calculées")
        return distributions
    
    def save_baseline(self, custom_path=None):
        """
        Sauvegarde la baseline et ses statistiques
        
        Args:
            custom_path (str): Chemin personnalisé (optionnel)
        """
        # Créer le répertoire si nécessaire
        save_dir = custom_path or BASELINE_CONFIG["save_path"]
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        
        logger.info(f"💾 Sauvegarde de la baseline dans {save_dir}...")
        
        # 1. Sauvegarder les données brutes (CSV)
        csv_path = os.path.join(save_dir, 'baseline_data.csv')
        self.baseline_data.to_csv(csv_path, index=False)
        logger.info(f"  ✅ Données brutes : {csv_path}")
        
        # 2. Sauvegarder les statistiques (JSON)
        # Créer une copie sans les valeurs brutes (trop volumineux)
        stats_to_save = {}
        for col, stats in self.baseline_stats.items():
            if isinstance(stats, dict):
                stats_copy = {k: v for k, v in stats.items() if k != 'values'}
                stats_to_save[col] = stats_copy
            else:
                stats_to_save[col] = stats
        
        json_path = os.path.join(save_dir, 'baseline_stats.json')
        with open(json_path, 'w') as f:
            json.dump(stats_to_save, f, indent=2)
        logger.info(f"  ✅ Statistiques : {json_path}")
        
        # 3. Sauvegarder les statistiques complètes (Pickle) pour tests KS
        pickle_path = os.path.join(save_dir, 'baseline_stats_full.pkl')
        with open(pickle_path, 'wb') as f:
            pickle.dump(self.baseline_stats, f)
        logger.info(f"  ✅ Stats complètes : {pickle_path}")
        
        # 4. Sauvegarder métadonnées
        metadata = {
            'creation_date': datetime.now().isoformat(),
            'sample_size': int(len(self.baseline_data)),
            'columns': list(self.baseline_data.columns),
            'temporal_range': self.baseline_stats.get('temporal', {}),
            'version': '1.0'
        }
        
        metadata_path = os.path.join(save_dir, 'baseline_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        logger.info(f"  ✅ Métadonnées : {metadata_path}")
        
        logger.info("✅ Baseline sauvegardée avec succès !")
    
    def load_baseline(self, custom_path=None):
        """
        Charge une baseline existante
        
        Args:
            custom_path (str): Chemin personnalisé
            
        Returns:
            dict: Statistiques de baseline
        """
        save_dir = custom_path or BASELINE_CONFIG["save_path"]
        
        logger.info(f"📂 Chargement de la baseline depuis {save_dir}...")
        
        # Charger les données
        csv_path = os.path.join(save_dir, 'baseline_data.csv')
        self.baseline_data = pd.read_csv(csv_path)
        self.baseline_data['timestamp'] = pd.to_datetime(self.baseline_data['timestamp'])
        
        # Charger les statistiques complètes
        pickle_path = os.path.join(save_dir, 'baseline_stats_full.pkl')
        with open(pickle_path, 'rb') as f:
            self.baseline_stats = pickle.load(f)
        
        logger.info("✅ Baseline chargée avec succès")
        return self.baseline_stats
    
    def print_summary(self):
        """
        Affiche un résumé de la baseline
        """
        if not self.baseline_stats:
            logger.warning("Aucune statistique calculée")
            return
        
        print("\n" + "="*70)
        print("📊 RÉSUMÉ DE LA BASELINE - GROUPE 7")
        print("="*70)
        
        # Informations temporelles
        if 'temporal' in self.baseline_stats:
            temp = self.baseline_stats['temporal']
            print(f"\n⏰ Période de référence :")
            print(f"  - Début      : {temp['start_date']}")
            print(f"  - Fin        : {temp['end_date']}")
            print(f"  - Durée      : {temp['duration_hours']:.1f} heures")
            print(f"  - Échantillon: {temp['sample_size']:,} lignes")
        
        # Statistiques par colonne
        print(f"\n📈 Statistiques descriptives :")
        print(f"\n{'Colonne':<25} {'Moyenne':<12} {'Écart-type':<12} {'Min':<10} {'Max':<10}")
        print("-" * 70)
        
        for col in ['global_active_power', 'voltage', 'global_intensity']:
            if col in self.baseline_stats:
                stats = self.baseline_stats[col]
                print(f"{col:<25} {stats['mean']:>11.3f} {stats['std']:>11.3f} "
                      f"{stats['min']:>9.3f} {stats['max']:>9.3f}")
        
        print("\n" + "="*70 + "\n")


# ============================================================================
# FONCTIONS UTILITAIRES
# ============================================================================

def create_baseline(sample_size=None, save=True):
    """
    Fonction helper pour créer rapidement une baseline
    
    Args:
        sample_size (int): Nombre de lignes
        save (bool): Sauvegarder automatiquement
        
    Returns:
        BaselineBuilder: Instance avec baseline créée
    """
    builder = BaselineBuilder(sample_size)
    builder.fetch_baseline_data()
    builder.calculate_statistics()
    builder.calculate_distribution_bins()
    
    if save:
        builder.save_baseline()
    
    return builder


# ============================================================================
# EXÉCUTION PRINCIPALE
# ============================================================================

if __name__ == "__main__":
    """
    Script principal pour créer la baseline
    """
    print("🚀 CRÉATION DE LA BASELINE - GROUPE 7")
    print("="*70 + "\n")
    
    try:
        # Créer la baseline
        logger.info("🔨 Démarrage de la création de la baseline...")
        builder = BaselineBuilder(sample_size=10000)
        
        # Étape 1 : Récupérer les données
        builder.fetch_baseline_data()
        
        # Étape 2 : Calculer les statistiques
        builder.calculate_statistics()
        
        # Étape 3 : Calculer les distributions
        builder.calculate_distribution_bins(n_bins=10)
        
        # Étape 4 : Afficher le résumé
        builder.print_summary()
        
        # Étape 5 : Sauvegarder
        builder.save_baseline()
        
        print("✅ BASELINE CRÉÉE AVEC SUCCÈS !")
        print("\n📁 Fichiers générés dans : data/baseline/")
        print("   - baseline_data.csv (données brutes)")
        print("   - baseline_stats.json (statistiques)")
        print("   - baseline_stats_full.pkl (pour tests KS)")
        print("   - baseline_metadata.json (métadonnées)")
        print("\n🎯 Prochaine étape : Implémentation des tests statistiques (Tâche 2)")
        
    except Exception as e:
        logger.error(f"❌ Erreur lors de la création de la baseline : {e}")
        import traceback
        traceback.print_exc()
        exit(1)
