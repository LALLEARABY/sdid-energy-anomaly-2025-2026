
import time
import logging
from datetime import datetime, timedelta
from pathlib import Path

from src.db_connector import DatabaseConnector
from src.statistical_tests import StatisticalTests
from config.drift_config import DRIFT_DETECTION_CONFIG

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DriftDetector:
    """
    Détecteur de dérive en temps réel.
    Distingue Data Drift et Concept Drift.
    """

    def __init__(self):
        self.db = DatabaseConnector()
        self.stat_tests = StatisticalTests()
        self.config = DRIFT_DETECTION_CONFIG

        # Charger la baseline
        self.stat_tests.load_baseline("data/baseline/")

        # Historique des détections
        self.drift_history = []

        logger.info("✅ DriftDetector initialisé")

    def detect_data_drift(self, hours=24):
        """
        Détecte les dérives de données (changement distribution).

        Args:
            hours (int): Fenêtre temporelle d'analyse

        Returns:
            dict: Résultats détection par colonne
        """
        logger.info(f"🔍 Détection Data Drift (dernières {hours}h)...")

        # Récupérer données récentes
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)

        df = self.db.fetch_data_range(start_time, end_time)

        if df.empty:
            logger.warning("Aucune donnée récente disponible")
            return None

        results = {}

        for column in self.config['monitored_columns']:
            if column in df.columns:
                # Exécuter tous les tests
                test_results = self.stat_tests.run_all_tests(
                    column,
                    df[column]
                )

                results[column] = {
                    'drift_detected': test_results['overall_drift_detected'],
                    'psi_value': test_results['tests']['psi']['psi_value'],
                    'ks_pvalue': test_results['tests']['kolmogorov_smirnov']['p_value'],
                    'severity': self._assess_severity(test_results)
                }

        return results

    def detect_concept_drift(self, hours=24):
        """
        Détecte les dérives de concept (changement comportement).

        Indicateurs:
        - Changement dans patterns temporels (jour/nuit)
        - Changement dans taux d'anomalies
        - Changement dans corrélations entre variables

        Args:
            hours (int): Fenêtre d'analyse

        Returns:
            dict: Indicateurs de concept drift
        """
        logger.info(f"🔍 Détection Concept Drift (dernières {hours}h)...")

        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)

        df = self.db.fetch_data_range(start_time, end_time)

        if df.empty:
            return None

        # 1. Analyser le pattern temporel
        if 'timestamp' in df.columns:
            df['hour'] = pd.to_datetime(df['timestamp']).dt.hour

            # Comparer distribution horaire avec baseline
            hourly_pattern = df.groupby('hour')['global_active_power'].mean()

        # 2. Analyser taux anomalies (si disponible)
        anomaly_rate_current = None
        if 'is_anomaly' in df.columns:
            anomaly_rate_current = df['is_anomaly'].mean()

        # 3. Analyser corrélations
        numeric_cols = ['global_active_power', 'voltage', 'global_intensity']
        current_corr = df[numeric_cols].corr()

        results = {
            'concept_drift_detected': False,  # À déterminer selon règles
            'temporal_pattern_changed': False,  # Comparer avec baseline
            'anomaly_rate_current': anomaly_rate_current,
            'correlation_matrix': current_corr.to_dict(),
            'timestamp': datetime.now().isoformat()
        }

        return results

    def monitor_continuous(self, interval_hours=6):
        """
        Surveillance continue avec intervalle configurable.

        Args:
            interval_hours (int): Intervalle entre vérifications (heures)
        """
        logger.info(f"🚀 Démarrage surveillance continue (intervalle: {interval_hours}h)")

        try:
            while True:
                logger.info("\n" + "=" * 70)
                logger.info(f"⏰ Vérification - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                logger.info("=" * 70)

                # Détection Data Drift
                data_drift_results = self.detect_data_drift(hours=24)

                # Détection Concept Drift
                concept_drift_results = self.detect_concept_drift(hours=24)

                # Sauvegarder résultats
                self._save_detection_results(data_drift_results, concept_drift_results)

                # Générer alerte si nécessaire
                if data_drift_results or concept_drift_results:
                    self._generate_alert(data_drift_results, concept_drift_results)

                # Attendre jusqu'à prochaine vérification
                logger.info(f"\n💤 Prochaine vérification dans {interval_hours}h...")
                time.sleep(interval_hours * 3600)

        except KeyboardInterrupt:
            logger.info("\n🛑 Surveillance arrêtée par l'utilisateur")
        except Exception as e:
            logger.error(f"❌ Erreur surveillance : {e}")
            raise

    def _assess_severity(self, test_results):
        """Évalue la sévérité de la dérive"""
        psi = test_results['tests']['psi']['psi_value']

        if psi >= 0.50:
            return 'CRITICAL'
        elif psi >= 0.25:
            return 'HIGH'
        elif psi >= 0.10:
            return 'MODERATE'
        else:
            return 'LOW'

    def _save_detection_results(self, data_drift, concept_drift):
        """Sauvegarde les résultats de détection"""
        import json

        results = {
            'timestamp': datetime.now().isoformat(),
            'data_drift': data_drift,
            'concept_drift': concept_drift
        }

        # Ajouter à l'historique
        self.drift_history.append(results)

        # Sauvegarder dans fichier
        alerts_path = Path(self.config['alerts_path'])
        alerts_path.parent.mkdir(parents=True, exist_ok=True)

        with open(alerts_path, 'w') as f:
            json.dump(self.drift_history, f, indent=2)

    def _generate_alert(self, data_drift, concept_drift):
        """Génère une alerte en cas de dérive détectée"""
        alert_triggered = False

        if data_drift:
            for column, result in data_drift.items():
                if result['drift_detected'] and result['severity'] in ['HIGH', 'CRITICAL']:
                    logger.warning(
                        f"🚨 ALERTE DATA DRIFT - {column}: "
                        f"PSI={result['psi_value']:.3f} (Sévérité: {result['severity']})"
                    )
                    alert_triggered = True

        if concept_drift and concept_drift.get('concept_drift_detected'):
            logger.warning("🚨 ALERTE CONCEPT DRIFT détecté")
            alert_triggered = True

        return alert_triggered


# ============================================================================
# EXÉCUTION PRINCIPALE
# ============================================================================

if __name__ == "__main__":
    print("🚀 DÉMARRAGE DRIFT DETECTOR - GROUPE 7")
    print("=" * 70 + "\n")

    detector = DriftDetector()

    # Mode surveillance continue
    detector.monitor_continuous(interval_hours=6)