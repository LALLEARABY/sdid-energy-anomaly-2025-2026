"""
Module de Tests Statistiques pour la Détection de Dérive - Groupe 7
Tâche 2 : Implémentation des Tests Statistiques

Ce module implémente :
- Test de Kolmogorov-Smirnov (KS Test)
- Population Stability Index (PSI)
- Jensen-Shannon Divergence
"""

import numpy as np
import pandas as pd
from scipy.stats import ks_2samp
from scipy.spatial.distance import jensenshannon
import logging
import json
from datetime import datetime
import sys
import os

# Imports locaux
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.drift_config import STATISTICAL_TESTS_CONFIG
from src.baseline_builder import BaselineBuilder

# Configuration logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class StatisticalTests:
    """
    Classe pour effectuer les tests statistiques de dérive
    """
    
    def __init__(self, baseline_stats=None):
        """
        Initialise les tests statistiques
        
        Args:
            baseline_stats (dict): Statistiques de référence
        """
        self.baseline_stats = baseline_stats
        self.config = STATISTICAL_TESTS_CONFIG
        
    def load_baseline(self, baseline_path="data/baseline/"):
        """
        Charge les statistiques de baseline
        
        Args:
            baseline_path (str): Chemin vers la baseline
        """
        builder = BaselineBuilder()
        self.baseline_stats = builder.load_baseline(baseline_path)
        logger.info("✅ Baseline chargée pour les tests statistiques")
    
    def kolmogorov_smirnov_test(self, column_name, new_data):
        """
        Test de Kolmogorov-Smirnov pour détecter un changement de distribution
        
        Args:
            column_name (str): Nom de la colonne à tester
            new_data (pd.Series): Nouvelles données à comparer
            
        Returns:
            dict: Résultats du test (statistic, p_value, drift_detected)
        """
        if self.baseline_stats is None:
            raise ValueError("Baseline non chargée. Appelez load_baseline() d'abord.")
        
        if column_name not in self.baseline_stats:
            raise ValueError(f"Colonne {column_name} non trouvée dans la baseline")
        
        # Récupérer les données de référence
        baseline_values = np.array(self.baseline_stats[column_name]['values'])
        new_values = new_data.dropna().values
        
        # Effectuer le test KS
        statistic, p_value = ks_2samp(baseline_values, new_values)
        
        # Déterminer si drift détecté
        threshold = self.config['ks_test']['alert_threshold']
        drift_detected = p_value < threshold
        
        result = {
            'test': 'Kolmogorov-Smirnov',
            'column': column_name,
            'statistic': float(statistic),
            'p_value': float(p_value),
            'threshold': threshold,
            'drift_detected': drift_detected,
            'interpretation': self._interpret_ks_test(p_value, threshold),
            'timestamp': datetime.now().isoformat()
        }
        
        if drift_detected:
            logger.warning(
                f"⚠️  DRIFT DÉTECTÉ sur {column_name} "
                f"(p-value={p_value:.4f} < {threshold})"
            )
        else:
            logger.info(
                f"✅ Pas de drift sur {column_name} "
                f"(p-value={p_value:.4f} >= {threshold})"
            )
        
        return result
    
    def population_stability_index(self, column_name, new_data):
        """
        Calcule le Population Stability Index (PSI)
        
        PSI = Σ (actual% - expected%) * ln(actual% / expected%)
        
        Interprétation :
        - PSI < 0.1  : Pas de changement significatif
        - PSI 0.1-0.25 : Changement modéré
        - PSI > 0.25 : Changement significatif
        
        Args:
            column_name (str): Nom de la colonne
            new_data (pd.Series): Nouvelles données
            
        Returns:
            dict: PSI et interprétation
        """
        if self.baseline_stats is None:
            raise ValueError("Baseline non chargée")
        
        if column_name not in self.baseline_stats:
            raise ValueError(f"Colonne {column_name} non trouvée")
        
        # Récupérer la distribution de référence
        baseline_dist = self.baseline_stats.get('distributions', {}).get(column_name)
        if not baseline_dist:
            logger.warning(f"Distribution baseline manquante pour {column_name}, calcul en cours...")
            return self._calculate_psi_from_raw_data(column_name, new_data)
        
        # Bins de référence
        bin_edges = np.array(baseline_dist['bin_edges'])
        expected_proportions = np.array(baseline_dist['proportions'])
        
        # Créer l'histogramme des nouvelles données avec les mêmes bins
        new_values = new_data.dropna().values
        actual_counts, _ = np.histogram(new_values, bins=bin_edges)
        actual_proportions = actual_counts / actual_counts.sum()
        
        # Éviter division par zéro
        expected_proportions = np.where(expected_proportions == 0, 0.0001, expected_proportions)
        actual_proportions = np.where(actual_proportions == 0, 0.0001, actual_proportions)
        
        # Calculer PSI
        psi = np.sum(
            (actual_proportions - expected_proportions) * 
            np.log(actual_proportions / expected_proportions)
        )
        
        # Interpréter
        interpretation = self._interpret_psi(psi)
        
        result = {
            'test': 'Population Stability Index',
            'column': column_name,
            'psi_value': float(psi),
            'interpretation': interpretation['category'],
            'severity': interpretation['severity'],
            'drift_detected': psi > self.config['psi']['alert_threshold'],
            'details': {
                'expected_proportions': expected_proportions.tolist(),
                'actual_proportions': actual_proportions.tolist(),
                'bin_edges': bin_edges.tolist()
            },
            'timestamp': datetime.now().isoformat()
        }
        
        if result['drift_detected']:
            logger.warning(
                f"⚠️  PSI ÉLEVÉ sur {column_name} : {psi:.4f} - {interpretation['category']}"
            )
        else:
            logger.info(
                f"✅ PSI acceptable sur {column_name} : {psi:.4f} - {interpretation['category']}"
            )
        
        return result
    
    def jensen_shannon_divergence(self, column_name, new_data):
        """
        Calcule la divergence de Jensen-Shannon
        
        Mesure la similarité entre deux distributions de probabilité
        Valeur entre 0 (identique) et 1 (totalement différentes)
        
        Args:
            column_name (str): Nom de la colonne
            new_data (pd.Series): Nouvelles données
            
        Returns:
            dict: Résultats JS divergence
        """
        if self.baseline_stats is None:
            raise ValueError("Baseline non chargée")
        
        # Récupérer la distribution baseline
        baseline_dist = self.baseline_stats.get('distributions', {}).get(column_name)
        if not baseline_dist:
            logger.warning(f"Distribution manquante pour {column_name}")
            return None
        
        bin_edges = np.array(baseline_dist['bin_edges'])
        baseline_props = np.array(baseline_dist['proportions'])
        
        # Distribution des nouvelles données
        new_values = new_data.dropna().values
        new_counts, _ = np.histogram(new_values, bins=bin_edges)
        new_props = new_counts / new_counts.sum()
        
        # Éviter les zéros (JS divergence ne les gère pas bien)
        baseline_props = np.where(baseline_props == 0, 1e-10, baseline_props)
        new_props = np.where(new_props == 0, 1e-10, new_props)
        
        # Calculer JS divergence
        js_div = jensenshannon(baseline_props, new_props)
        
        threshold = self.config['js_divergence']['alert_threshold']
        drift_detected = js_div > threshold
        
        result = {
            'test': 'Jensen-Shannon Divergence',
            'column': column_name,
            'js_divergence': float(js_div),
            'threshold': threshold,
            'drift_detected': drift_detected,
            'interpretation': self._interpret_js_divergence(js_div),
            'timestamp': datetime.now().isoformat()
        }
        
        return result
    
    def run_all_tests(self, column_name, new_data):
        """
        Exécute tous les tests statistiques sur une colonne
        
        Args:
            column_name (str): Nom de la colonne
            new_data (pd.Series): Nouvelles données
            
        Returns:
            dict: Résultats de tous les tests
        """
        logger.info(f"🧪 Exécution de tous les tests sur {column_name}...")
        
        results = {
            'column': column_name,
            'sample_size': len(new_data.dropna()),
            'tests': {}
        }
        
        # Test KS
        try:
            results['tests']['kolmogorov_smirnov'] = self.kolmogorov_smirnov_test(
                column_name, new_data
            )
        except Exception as e:
            logger.error(f"Erreur test KS : {e}")
            results['tests']['kolmogorov_smirnov'] = {'error': str(e)}
        
        # PSI
        try:
            results['tests']['psi'] = self.population_stability_index(
                column_name, new_data
            )
        except Exception as e:
            logger.error(f"Erreur PSI : {e}")
            results['tests']['psi'] = {'error': str(e)}
        
        # JS Divergence
        try:
            results['tests']['js_divergence'] = self.jensen_shannon_divergence(
                column_name, new_data
            )
        except Exception as e:
            logger.error(f"Erreur JS : {e}")
            results['tests']['js_divergence'] = {'error': str(e)}
        
        # Synthèse
        results['overall_drift_detected'] = any(
            test_result.get('drift_detected', False)
            for test_result in results['tests'].values()
            if isinstance(test_result, dict) and 'drift_detected' in test_result
        )
        
        return results
    
    # ========================================================================
    # MÉTHODES PRIVÉES D'INTERPRÉTATION
    # ========================================================================
    
    def _interpret_ks_test(self, p_value, threshold):
        """Interprète le résultat du test KS"""
        if p_value < 0.01:
            return "Différence très significative (p < 0.01)"
        elif p_value < threshold:
            return f"Différence significative (p < {threshold})"
        elif p_value < 0.1:
            return "Différence modérée (p < 0.1)"
        else:
            return "Pas de différence significative"
    
    def _interpret_psi(self, psi_value):
        """Interprète la valeur PSI"""
        if psi_value < 0.1:
            return {
                'category': 'Stable',
                'severity': 'low',
                'description': 'Pas de changement significatif'
            }
        elif psi_value < 0.25:
            return {
                'category': 'Dérive modérée',
                'severity': 'medium',
                'description': 'Changement modéré, surveillance recommandée'
            }
        else:
            return {
                'category': 'Dérive significative',
                'severity': 'high',
                'description': 'Changement important, action requise'
            }
    
    def _interpret_js_divergence(self, js_div):
        """Interprète la JS divergence"""
        if js_div < 0.1:
            return "Distributions très similaires"
        elif js_div < 0.2:
            return "Distributions modérément différentes"
        else:
            return "Distributions significativement différentes"
    
    def _calculate_psi_from_raw_data(self, column_name, new_data):
        """Calcule PSI directement depuis les données brutes si nécessaire"""
        baseline_values = np.array(self.baseline_stats[column_name]['values'])
        new_values = new_data.dropna().values
        
        n_bins = self.config['psi']['bins']
        
        # Créer les bins sur la baseline
        expected_counts, bin_edges = np.histogram(baseline_values, bins=n_bins)
        expected_props = expected_counts / expected_counts.sum()
        
        # Appliquer les mêmes bins aux nouvelles données
        actual_counts, _ = np.histogram(new_values, bins=bin_edges)
        actual_props = actual_counts / actual_counts.sum()
        
        # Éviter division par zéro
        expected_props = np.where(expected_props == 0, 0.0001, expected_props)
        actual_props = np.where(actual_props == 0, 0.0001, actual_props)
        
        # PSI
        psi = np.sum(
            (actual_props - expected_props) * 
            np.log(actual_props / expected_props)
        )
        
        interpretation = self._interpret_psi(psi)
        
        return {
            'test': 'PSI (calculé)',
            'column': column_name,
            'psi_value': float(psi),
            'interpretation': interpretation['category'],
            'drift_detected': psi > self.config['psi']['alert_threshold']
        }


# ============================================================================
# FONCTIONS UTILITAIRES
# ============================================================================

def compare_periods(baseline_path, new_data_df, columns=None):
    """
    Compare les données récentes avec la baseline
    
    Args:
        baseline_path (str): Chemin de la baseline
        new_data_df (pd.DataFrame): Nouvelles données
        columns (list): Colonnes à tester
        
    Returns:
        dict: Résultats pour toutes les colonnes
    """
    tester = StatisticalTests()
    tester.load_baseline(baseline_path)
    
    if columns is None:
        columns = ['global_active_power', 'voltage', 'global_intensity']
    
    all_results = {}
    for col in columns:
        if col in new_data_df.columns:
            all_results[col] = tester.run_all_tests(col, new_data_df[col])
    
    return all_results


# ============================================================================
# TEST DU MODULE
# ============================================================================

if __name__ == "__main__":
    """
    Test du module de tests statistiques
    """
    print("🧪 TEST DES TESTS STATISTIQUES - GROUPE 7")
    print("="*70 + "\n")
    
    # Charger la baseline
    logger.info("📂 Chargement de la baseline...")
    tester = StatisticalTests()
    
    try:
        tester.load_baseline("data/baseline/")
        
        # Générer des données de test (simulées)
        logger.info("🎲 Génération de données de test...")
        np.random.seed(42)
        
        # Scénario 1 : Données similaires (pas de drift)
        baseline_mean = tester.baseline_stats['global_active_power']['mean']
        baseline_std = tester.baseline_stats['global_active_power']['std']
        similar_data = pd.Series(
            np.random.normal(baseline_mean, baseline_std, 1000)
        )
        
        print("\n📊 SCÉNARIO 1 : Données similaires (pas de drift attendu)")
        print("-" * 70)
        result1 = tester.run_all_tests('global_active_power', similar_data)
        print(f"Drift détecté : {result1['overall_drift_detected']}")
        print(f"  - KS p-value : {result1['tests']['kolmogorov_smirnov']['p_value']:.4f}")
        print(f"  - PSI       : {result1['tests']['psi']['psi_value']:.4f}")
        
        # Scénario 2 : Données décalées (drift attendu)
        drifted_data = pd.Series(
            np.random.normal(baseline_mean * 1.5, baseline_std, 1000)
        )
        
        print("\n📊 SCÉNARIO 2 : Données décalées (+50%, drift attendu)")
        print("-" * 70)
        result2 = tester.run_all_tests('global_active_power', drifted_data)
        print(f"Drift détecté : {result2['overall_drift_detected']}")
        print(f"  - KS p-value : {result2['tests']['kolmogorov_smirnov']['p_value']:.4f}")
        print(f"  - PSI       : {result2['tests']['psi']['psi_value']:.4f}")
        
        print("\n✅ Tests statistiques fonctionnels !")
        print("🎯 Prochaine étape : Intégration avec données temps réel (Tâche 3)")
        
    except FileNotFoundError:
        logger.error("❌ Baseline non trouvée. Exécutez d'abord baseline_builder.py")
        exit(1)
    except Exception as e:
        logger.error(f"❌ Erreur : {e}")
        import traceback
        traceback.print_exc()
        exit(1)
