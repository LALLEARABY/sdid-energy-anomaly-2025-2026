"""
Module de connexion à PostgreSQL - Groupe 7
Gère les connexions à la base de données créée par G2
"""

import psycopg2
import pandas as pd
from sqlalchemy import create_engine
import logging
import sys
import os

# Ajouter le répertoire parent au path pour importer config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.drift_config import DB_CONFIG, get_db_connection_string

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DatabaseConnector:
    """
    Classe pour gérer les connexions à PostgreSQL
    """
    
    def __init__(self):
        """
        Initialise le connecteur de base de données
        """
        self.config = DB_CONFIG
        self.engine = None
        self.connection = None
        
    def connect(self):
        """
        Établit une connexion à la base de données
        
        Returns:
            bool: True si connexion réussie, False sinon
        """
        try:
            # Créer le moteur SQLAlchemy
            connection_string = get_db_connection_string()
            self.engine = create_engine(connection_string)
            
            # Tester la connexion
            with self.engine.connect() as conn:
                result = conn.execute("SELECT 1")
                logger.info("✅ Connexion à la base de données établie avec succès")
                return True
                
        except Exception as e:
            logger.error(f"❌ Erreur de connexion à la base de données : {e}")
            return False
    
    def get_psycopg2_connection(self):
        """
        Retourne une connexion psycopg2 (pour opérations bas niveau)
        
        Returns:
            psycopg2.connection: Objet de connexion
        """
        try:
            conn = psycopg2.connect(**self.config)
            logger.debug("Connexion psycopg2 créée")
            return conn
        except Exception as e:
            logger.error(f"Erreur création connexion psycopg2 : {e}")
            raise
    
    def fetch_data(self, query, params=None):
        """
        Exécute une requête SELECT et retourne un DataFrame
        
        Args:
            query (str): Requête SQL
            params (dict, optional): Paramètres de la requête
            
        Returns:
            pd.DataFrame: Résultats de la requête
        """
        try:
            df = pd.read_sql(query, self.engine, params=params)
            logger.info(f"✅ Données récupérées : {len(df)} lignes")
            return df
        except Exception as e:
            logger.error(f"❌ Erreur lors de la récupération des données : {e}")
            raise
    
    def fetch_baseline_data(self, limit=10000):
        """
        Récupère les premières données pour créer la baseline
        
        Args:
            limit (int): Nombre de lignes à récupérer
            
        Returns:
            pd.DataFrame: Données de base
        """
        query = f"""
        SELECT 
            timestamp,
            global_active_power,
            global_reactive_power,
            voltage,
            global_intensity,
            sub_metering_1,
            sub_metering_2,
            sub_metering_3
        FROM power_consumption
        WHERE global_active_power IS NOT NULL
          AND voltage IS NOT NULL
        ORDER BY timestamp ASC
        LIMIT {limit}
        """
        
        logger.info(f"📥 Récupération de {limit} lignes pour la baseline...")
        return self.fetch_data(query)
    
    def fetch_recent_data(self, hours=24):
        """
        Récupère les données récentes (dernières X heures)
        
        Args:
            hours (int): Nombre d'heures à récupérer
            
        Returns:
            pd.DataFrame: Données récentes
        """
        query = f"""
        SELECT 
            timestamp,
            global_active_power,
            global_reactive_power,
            voltage,
            global_intensity,
            sub_metering_1,
            sub_metering_2,
            sub_metering_3,
            is_anomaly
        FROM power_consumption
        WHERE timestamp >= NOW() - INTERVAL '{hours} hours'
          AND global_active_power IS NOT NULL
        ORDER BY timestamp DESC
        """
        
        logger.info(f"📥 Récupération des données des {hours} dernières heures...")
        return self.fetch_data(query)
    
    def fetch_time_range_data(self, start_date, end_date):
        """
        Récupère les données pour une période spécifique
        
        Args:
            start_date (str): Date de début (format: 'YYYY-MM-DD HH:MM:SS')
            end_date (str): Date de fin (format: 'YYYY-MM-DD HH:MM:SS')
            
        Returns:
            pd.DataFrame: Données de la période
        """
        query = """
        SELECT 
            timestamp,
            global_active_power,
            global_reactive_power,
            voltage,
            global_intensity,
            sub_metering_1,
            sub_metering_2,
            sub_metering_3,
            is_anomaly
        FROM power_consumption
        WHERE timestamp BETWEEN %(start)s AND %(end)s
          AND global_active_power IS NOT NULL
        ORDER BY timestamp ASC
        """
        
        params = {"start": start_date, "end": end_date}
        logger.info(f"📥 Récupération des données entre {start_date} et {end_date}...")
        return self.fetch_data(query, params)
    
    def get_table_info(self):
        """
        Récupère les informations sur la table power_consumption
        
        Returns:
            dict: Informations sur la table
        """
        try:
            # Nombre total de lignes
            count_query = "SELECT COUNT(*) as count FROM power_consumption"
            count_df = self.fetch_data(count_query)
            total_rows = count_df['count'].iloc[0]
            
            # Date min et max
            date_query = """
            SELECT 
                MIN(timestamp) as min_date,
                MAX(timestamp) as max_date
            FROM power_consumption
            """
            date_df = self.fetch_data(date_query)
            
            # Nombre d'anomalies (si G4 a rempli)
            anomaly_query = """
            SELECT 
                COUNT(*) FILTER (WHERE is_anomaly = TRUE) as anomaly_count
            FROM power_consumption
            """
            anomaly_df = self.fetch_data(anomaly_query)
            
            info = {
                "total_rows": int(total_rows),
                "min_date": date_df['min_date'].iloc[0],
                "max_date": date_df['max_date'].iloc[0],
                "anomaly_count": int(anomaly_df['anomaly_count'].iloc[0]) if anomaly_df['anomaly_count'].iloc[0] else 0
            }
            
            logger.info("ℹ️  Informations table récupérées")
            return info
            
        except Exception as e:
            logger.error(f"❌ Erreur récupération infos table : {e}")
            raise
    
    def test_connection(self):
        """
        Teste la connexion et affiche les informations de la base
        
        Returns:
            bool: True si test réussi
        """
        try:
            if not self.connect():
                return False
            
            print("\n" + "="*60)
            print("🔍 TEST DE CONNEXION - BASE DE DONNÉES G2")
            print("="*60)
            
            # Afficher la configuration
            print(f"\n📊 Configuration :")
            print(f"  - Host     : {self.config['host']}")
            print(f"  - Port     : {self.config['port']}")
            print(f"  - Database : {self.config['dbname']}")
            print(f"  - User     : {self.config['user']}")
            
            # Afficher les infos de la table
            info = self.get_table_info()
            print(f"\n📈 Table 'power_consumption' :")
            print(f"  - Lignes totales    : {info['total_rows']:,}")
            print(f"  - Date minimum      : {info['min_date']}")
            print(f"  - Date maximum      : {info['max_date']}")
            print(f"  - Anomalies (G4)    : {info['anomaly_count']:,}")
            
            # Afficher un échantillon
            print(f"\n📋 Échantillon de données (5 premières lignes) :")
            sample = self.fetch_data("SELECT * FROM power_consumption LIMIT 5")
            print(sample.to_string(index=False))
            
            print("\n" + "="*60)
            print("✅ Test de connexion réussi !")
            print("="*60 + "\n")
            
            return True
            
        except Exception as e:
            print(f"\n❌ Échec du test de connexion : {e}\n")
            return False
    
    def close(self):
        """
        Ferme les connexions
        """
        if self.engine:
            self.engine.dispose()
            logger.info("🔒 Connexions fermées")


# ============================================================================
# FONCTIONS UTILITAIRES
# ============================================================================

def get_connection():
    """
    Fonction helper pour obtenir rapidement une connexion
    
    Returns:
        DatabaseConnector: Instance connectée
    """
    db = DatabaseConnector()
    if db.connect():
        return db
    else:
        raise ConnectionError("Impossible de se connecter à la base de données")


def quick_query(query, params=None):
    """
    Exécute rapidement une requête et retourne les résultats
    
    Args:
        query (str): Requête SQL
        params (dict, optional): Paramètres
        
    Returns:
        pd.DataFrame: Résultats
    """
    db = get_connection()
    try:
        return db.fetch_data(query, params)
    finally:
        db.close()


# ============================================================================
# TEST DU MODULE
# ============================================================================

if __name__ == "__main__":
    """
    Test du module de connexion
    """
    print("🚀 Démarrage du test de connexion PostgreSQL (G2)...\n")
    
    # Créer le connecteur
    db = DatabaseConnector()
    
    # Tester la connexion
    success = db.test_connection()
    
    # Fermer la connexion
    db.close()
    
    if success:
        print("✅ Module db_connector.py fonctionnel !")
        print("📝 Vous pouvez maintenant utiliser ce module dans vos scripts.")
        exit(0)
    else:
        print("❌ Problème de connexion. Vérifiez :")
        print("   1. PostgreSQL est démarré (docker-compose up)")
        print("   2. Les credentials dans config/drift_config.py")
        print("   3. La table 'power_consumption' existe")
        exit(1)
