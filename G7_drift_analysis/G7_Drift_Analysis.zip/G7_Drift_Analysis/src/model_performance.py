"""
Model Performance Evaluator - Groupe 7
Mesure de l'obsolescence des modèles G3 (Clustering) et G4 (Anomaly Detection)
"""

import sys
import os
import json
import pickle
import warnings
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix

# Configuration locale
sys.path.append(str(Path(__file__).parent.parent))

from src.db_connector import DatabaseConnector
from config.drift_config import (
    MODEL_PERFORMANCE_CONFIG,
    G3_ARTIFACTS_PATHS,
    G4_ARTIFACTS_PATHS,
    get_monitoring_path
)

warnings.filterwarnings('ignore')


class ModelPerformanceEvaluator:
    """
    Évalue la performance et l'obsolescence des modèles de ML.
    """

    def __init__(self):
        """Initialise l'évaluateur de performance."""
        self.db = DatabaseConnector()
        self.g3_metrics_history = []
        self.g4_metrics_history = []

        # Charger les modèles et artéfacts
        self._load_artifacts()

        print("✅ ModelPerformanceEvaluator initialisé")

    def _load_artifacts(self):
        """Charge les artéfacts des groupes G3 et G4."""
        print("📦 Chargement des artéfacts...")

        # G3 Artifacts
        try:
            # Scaler
            scaler_path = G3_ARTIFACTS_PATHS['scaler']
            if os.path.exists(scaler_path):
                with open(scaler_path, 'rb') as f:
                    self.g3_scaler = pickle.load(f)
                print(f"  ✅ G3 Scaler chargé")
            else:
                self.g3_scaler = None
                print(f"  ⚠️  G3 Scaler non trouvé: {scaler_path}")

            # PCA
            pca_path = G3_ARTIFACTS_PATHS['pca']
            if os.path.exists(pca_path):
                with open(pca_path, 'rb') as f:
                    self.g3_pca = pickle.load(f)
                print(f"  ✅ G3 PCA chargé")
            else:
                self.g3_pca = None
                print(f"  ⚠️  G3 PCA non trouvé: {pca_path}")

            # Clusters
            clusters_path = G3_ARTIFACTS_PATHS['clusters']
            if os.path.exists(clusters_path):
                with open(clusters_path, 'r') as f:
                    self.g3_clusters = json.load(f)
                print(f"  ✅ G3 Clusters chargés")
            else:
                self.g3_clusters = None
                print(f"  ⚠️  G3 Clusters non trouvés: {clusters_path}")

        except Exception as e:
            print(f"  ❌ Erreur chargement G3: {e}")
            self.g3_scaler = None
            self.g3_pca = None
            self.g3_clusters = None

        # G4 Artifacts
        try:
            # Isolation Forest
            if_path = G4_ARTIFACTS_PATHS['isolation_forest']
            if os.path.exists(if_path):
                with open(if_path, 'rb') as f:
                    self.g4_model = pickle.load(f)
                print(f"  ✅ G4 Isolation Forest chargé")
            else:
                self.g4_model = None
                print(f"  ⚠️  G4 Model non trouvé: {if_path}")

        except Exception as e:
            print(f"  ❌ Erreur chargement G4: {e}")
            self.g4_model = None

    def evaluate_g3_clustering(self, recent_hours=168):
        """
        Évalue la performance du clustering G3.

        Args:
            recent_hours (int): Heures de données récentes à analyser

        Returns:
            dict: Métriques de performance
        """
        print(f"\n📊 Évaluation G3 (Clustering) - Dernières {recent_hours}h")

        if self.g3_scaler is None or self.g3_pca is None:
            return {"error": "Artéfacts G3 non disponibles"}

        # Récupérer données récentes
        df = self.db.fetch_recent_data(hours=recent_hours)

        if df.empty:
            return {"error": "Pas de données récentes"}

        # Préparer les données
        feature_columns = ['global_active_power', 'global_reactive_power', 'voltage', 'global_intensity']
        X = df[feature_columns].dropna()

        if len(X) < 100:
            return {"error": "Pas assez de données"}

        # Normaliser
        X_scaled = self.g3_scaler.transform(X)

        # Appliquer PCA
        X_pca = self.g3_pca.transform(X_scaled)

        # Assigner aux clusters (simulation avec K-Means sur les données PCA)
        from sklearn.cluster import KMeans
        n_clusters = len(set(self.g3_clusters.get('cluster_labels', [0]))) if self.g3_clusters else 3
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        labels = kmeans.fit_predict(X_pca)

        # Calculer les métriques
        silhouette = silhouette_score(X_pca, labels)
        davies_bouldin = davies_bouldin_score(X_pca, labels)

        # Comparer avec les seuils
        silhouette_threshold = MODEL_PERFORMANCE_CONFIG['g3_metrics']['silhouette_threshold']

        performance_ok = silhouette >= silhouette_threshold

        # Calculer la stabilité des clusters (pourcentage de points dans chaque cluster)
        unique, counts = np.unique(labels, return_counts=True)
        cluster_distribution = dict(zip(unique.tolist(), counts.tolist()))

        # Stabilité = entropie normalisée (plus proche de 1 = mieux distribué)
        probs = counts / counts.sum()
        entropy = -np.sum(probs * np.log(probs + 1e-10))
        max_entropy = np.log(len(unique))
        stability = entropy / max_entropy if max_entropy > 0 else 0

        result = {
            'timestamp': datetime.now().isoformat(),
            'recent_hours': recent_hours,
            'n_samples': len(X),
            'n_clusters': n_clusters,
            'metrics': {
                'silhouette_score': round(silhouette, 4),
                'davies_bouldin_index': round(davies_bouldin, 4),
                'cluster_stability': round(stability, 4)
            },
            'thresholds': {
                'silhouette_threshold': silhouette_threshold,
            },
            'performance_ok': performance_ok,
            'cluster_distribution': cluster_distribution,
            'status': 'BON' if performance_ok else 'DÉGRADÉ'
        }

        print(f"  Silhouette Score: {silhouette:.4f} (seuil: {silhouette_threshold})")
        print(f"  Davies-Bouldin: {davies_bouldin:.4f} (plus bas = mieux)")
        print(f"  Stabilité Clusters: {stability:.4f}")
        print(f"  Statut: {result['status']}")

        # Sauvegarder dans l'historique
        self.g3_metrics_history.append(result)

        return result

    def evaluate_g4_anomaly_detection(self, recent_hours=168, ground_truth=None):
        """
        Évalue la performance de la détection d'anomalies G4.

        Args:
            recent_hours (int): Heures de données récentes
            ground_truth (pd.Series): Vraies étiquettes (si disponibles)

        Returns:
            dict: Métriques de performance
        """
        print(f"\n📊 Évaluation G4 (Anomaly Detection) - Dernières {recent_hours}h")

        if self.g4_model is None:
            return {"error": "Modèle G4 non disponible"}

        # Récupérer données récentes
        df = self.db.fetch_recent_data(hours=recent_hours)

        if df.empty:
            return {"error": "Pas de données récentes"}

        # Préparer les données
        feature_columns = ['global_active_power', 'global_reactive_power', 'voltage', 'global_intensity']
        X = df[feature_columns].dropna()

        if len(X) < 100:
            return {"error": "Pas assez de données"}

        # Prédire les anomalies
        predictions = self.g4_model.predict(X)
        # Isolation Forest: -1 = anomalie, 1 = normal
        # Convertir: 1 = anomalie, 0 = normal
        y_pred = (predictions == -1).astype(int)

        # Calculer les scores
        scores = self.g4_model.decision_function(X)

        # Taux d'anomalies
        anomaly_rate = (y_pred == 1).mean()

        # Si pas de ground truth, simuler (pour démo)
        if ground_truth is None:
            # Simulation basique: considérer les valeurs extrêmes comme vraies anomalies
            power = X['global_active_power']
            q1, q3 = power.quantile([0.05, 0.95])
            y_true = ((power < q1) | (power > q3)).astype(int)
        else:
            y_true = ground_truth

        # Calculer les métriques
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)

        # Matrice de confusion
        cm = confusion_matrix(y_true, y_pred)
        tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)

        # Taux de faux positifs
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0

        # Comparer avec les seuils
        thresholds = MODEL_PERFORMANCE_CONFIG['g4_metrics']

        performance_ok = (
                precision >= thresholds['precision_threshold'] and
                recall >= thresholds['recall_threshold'] and
                fpr <= thresholds['false_positive_rate_max']
        )

        result = {
            'timestamp': datetime.now().isoformat(),
            'recent_hours': recent_hours,
            'n_samples': len(X),
            'anomaly_rate': round(anomaly_rate, 4),
            'metrics': {
                'precision': round(precision, 4),
                'recall': round(recall, 4),
                'f1_score': round(f1, 4),
                'false_positive_rate': round(fpr, 4)
            },
            'confusion_matrix': {
                'true_negatives': int(tn),
                'false_positives': int(fp),
                'false_negatives': int(fn),
                'true_positives': int(tp)
            },
            'thresholds': thresholds,
            'performance_ok': performance_ok,
            'status': 'BON' if performance_ok else 'DÉGRADÉ'
        }

        print(f"  Précision: {precision:.4f} (seuil: {thresholds['precision_threshold']})")
        print(f"  Rappel: {recall:.4f} (seuil: {thresholds['recall_threshold']})")
        print(f"  F1-Score: {f1:.4f}")
        print(f"  Taux FP: {fpr:.4f} (max: {thresholds['false_positive_rate_max']})")
        print(f"  Taux d'anomalies: {anomaly_rate:.2%}")
        print(f"  Statut: {result['status']}")

        # Sauvegarder dans l'historique
        self.g4_metrics_history.append(result)

        return result

    def detect_model_degradation(self):
        """
        Détecte si les modèles se dégradent au fil du temps.

        Returns:
            dict: Résultats de dégradation
        """
        print("\n🔍 Analyse de dégradation des modèles...")

        degradation = {
            'timestamp': datetime.now().isoformat(),
            'g3_degradation': False,
            'g4_degradation': False,
            'details': {}
        }

        # Analyser G3
        if len(self.g3_metrics_history) >= 2:
            recent = self.g3_metrics_history[-1]
            baseline = self.g3_metrics_history[0]

            sil_drop = baseline['metrics']['silhouette_score'] - recent['metrics']['silhouette_score']
            sil_drop_pct = (sil_drop / baseline['metrics']['silhouette_score']) * 100

            degradation['g3_degradation'] = sil_drop_pct > 10  # Baisse > 10%
            degradation['details']['g3'] = {
                'silhouette_drop_pct': round(sil_drop_pct, 2),
                'baseline_silhouette': baseline['metrics']['silhouette_score'],
                'current_silhouette': recent['metrics']['silhouette_score']
            }

            print(f"  G3: Baisse silhouette = {sil_drop_pct:.2f}%")

        # Analyser G4
        if len(self.g4_metrics_history) >= 2:
            recent = self.g4_metrics_history[-1]
            baseline = self.g4_metrics_history[0]

            precision_drop = baseline['metrics']['precision'] - recent['metrics']['precision']
            precision_drop_pct = (precision_drop / baseline['metrics']['precision']) * 100

            degradation['g4_degradation'] = precision_drop_pct > 10  # Baisse > 10%
            degradation['details']['g4'] = {
                'precision_drop_pct': round(precision_drop_pct, 2),
                'baseline_precision': baseline['metrics']['precision'],
                'current_precision': recent['metrics']['precision']
            }

            print(f"  G4: Baisse précision = {precision_drop_pct:.2f}%")

        return degradation

    def save_metrics_history(self):
        """Sauvegarde l'historique des métriques."""
        metrics_file = get_monitoring_path('model_metrics_history.json')

        history = {
            'g3_clustering': self.g3_metrics_history,
            'g4_anomaly_detection': self.g4_metrics_history,
            'last_updated': datetime.now().isoformat()
        }

        with open(metrics_file, 'w') as f:
            json.dump(history, f, indent=2)

        print(f"\n💾 Historique sauvegardé: {metrics_file}")

    def generate_performance_report(self):
        """Génère un rapport complet de performance."""
        print("\n" + "=" * 60)
        print("📊 RAPPORT DE PERFORMANCE DES MODÈLES")
        print("=" * 60)

        # Évaluer G3
        g3_result = self.evaluate_g3_clustering()

        # Évaluer G4
        g4_result = self.evaluate_g4_anomaly_detection()

        # Détecter dégradation
        degradation = self.detect_model_degradation()

        # Sauvegarder
        self.save_metrics_history()

        print("\n" + "=" * 60)
        print("✅ Rapport de performance généré")
        print("=" * 60)

        return {
            'g3': g3_result,
            'g4': g4_result,
            'degradation': degradation
        }


def main():
    """Point d'entrée principal."""
    evaluator = ModelPerformanceEvaluator()
    evaluator.generate_performance_report()


if __name__ == "__main__":
    main()