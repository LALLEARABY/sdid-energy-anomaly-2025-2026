

from datetime import datetime, timedelta
import json
from pathlib import Path

from src.db_connector import DatabaseConnector
from config.drift_config import ECONOMIC_IMPACT_CONFIG


class EconomicImpactCalculator:
    """
    Calcule l'impact économique du système de détection.
    """

    def __init__(self):
        self.db = DatabaseConnector()
        self.config = ECONOMIC_IMPACT_CONFIG

    def calculate_monthly_roi(self):
        """
        Calcule le ROI mensuel du système.

        Returns:
            dict: Rapport économique complet
        """
        # Récupérer données du dernier mois
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)

        df = self.db.fetch_data_range(start_date, end_date)

        if 'is_anomaly' not in df.columns:
            return None

        # Compter les détections
        total_anomalies = df['is_anomaly'].sum()
        total_normal = len(df) - total_anomalies

        # Estimation coûts (simplifié - nécessite validation métier)
        # Hypothèses:
        # - 10% des anomalies = vrais positifs (gains)
        # - 5% des anomalies = faux positifs (coûts)
        # - 2% des normales = faux négatifs (coûts manqués)

        true_positives = int(total_anomalies * 0.10)
        false_positives = int(total_anomalies * 0.05)
        false_negatives = int(total_normal * 0.02)

        # Calcul coûts/gains
        gain_tp = true_positives * abs(self.config['cost_true_positive'])
        cost_fp = false_positives * self.config['cost_false_positive']
        cost_fn = false_negatives * self.config['cost_false_negative']

        total_cost = cost_fp + cost_fn
        total_gain = gain_tp
        net_benefit = total_gain - total_cost

        # ROI
        system_cost = 5000  # Coût système mensuel (à ajuster)
        roi = ((net_benefit - system_cost) / system_cost) * 100

        report = {
            'period': {
                'start': start_date.isoformat(),
                'end': end_date.isoformat(),
                'days': 30
            },
            'detections': {
                'total_records': len(df),
                'anomalies_detected': int(total_anomalies),
                'true_positives_est': true_positives,
                'false_positives_est': false_positives,
                'false_negatives_est': false_negatives
            },
            'economics': {
                'gain_from_detections': float(gain_tp),
                'cost_false_positives': float(cost_fp),
                'cost_false_negatives': float(cost_fn),
                'total_cost': float(total_cost),
                'total_gain': float(total_gain),
                'net_benefit': float(net_benefit),
                'system_cost': float(system_cost),
                'roi_percentage': float(roi)
            },
            'interpretation': self._interpret_roi(roi),
            'timestamp': datetime.now().isoformat()
        }

        # Sauvegarder
        self._save_report(report)

        return report

    def _interpret_roi(self, roi):
        """Interprète le ROI"""
        if roi > 100:
            return "Excellent - ROI très positif"
        elif roi > 50:
            return "Bon - ROI positif"
        elif roi > 0:
            return "Acceptable - ROI légèrement positif"
        else:
            return "Négatif - Réévaluation nécessaire"

    def _save_report(self, report):
        """Sauvegarde le rapport"""
        output_path = Path(self.config['economic_reports_path'])
        output_path.mkdir(parents=True, exist_ok=True)

        filename = f"economic_impact_{datetime.now().strftime('%Y%m')}.json"
        filepath = output_path / filename

        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2)

        print(f"💾 Rapport économique sauvegardé: {filepath}")


if __name__ == "__main__":
    calc = EconomicImpactCalculator()
    report = calc.calculate_monthly_roi()

    if report:
        print("\n💰 RAPPORT ÉCONOMIQUE MENSUEL")
        print("=" * 70)
        print(f"ROI: {report['economics']['roi_percentage']:.1f}%")
        print(f"Bénéfice net: {report['economics']['net_benefit']:.2f} €")
        print(f"Interprétation: {report['interpretation']}")