"""
Retraining Strategy - Groupe 7
Planification automatisée du ré-entraînement des modèles
"""

import sys
import os
import json
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

# Configuration locale
sys.path.append(str(Path(__file__).parent.parent))

from src.db_connector import DatabaseConnector
from src.statistical_tests import StatisticalTests
from src.model_performance import ModelPerformanceEvaluator
from config.drift_config import (
    RETRAINING_STRATEGY_CONFIG,
    get_monitoring_path
)


class RetrainingStrategy:
    """
    Gère la stratégie de ré-entraînement automatique des modèles.
    """

    def __init__(self):
        """Initialise la stratégie de ré-entraînement."""
        self.db = DatabaseConnector()
        self.stat_tests = StatisticalTests()
        self.perf_evaluator = ModelPerformanceEvaluator()

        # Seuils déclencheurs
        self.triggers = RETRAINING_STRATEGY_CONFIG['triggers']
        self.retraining_params = RETRAINING_STRATEGY_CONFIG['retraining']

        # Historique des ré-entraînements
        self.retraining_history = []

        print("✅ RetrainingStrategy initialisée")
        print(f"🎯 Seuils déclencheurs:")
        print(f"   - PSI > {self.triggers['psi_threshold']}")
        print(f"   - Baisse performance > {self.triggers['performance_drop_threshold'] * 100}%")
        print(f"   - Drift persistant > {self.triggers['drift_duration_days']} jours")

    def check_psi_trigger(self, column='global_active_power', consecutive_days=3):
        """
        Vérifie si le PSI dépasse le seuil pendant N jours consécutifs.

        Args:
            column (str): Colonne à vérifier
            consecutive_days (int): Nombre de jours consécutifs requis

        Returns:
            dict: Résultat de la vérification
        """
        print(f"\n🔍 Vérification PSI ({column})...")

        psi_values = []

        # Vérifier les N derniers jours
        for day in range(consecutive_days):
            # Récupérer données du jour
            end_time = datetime.now() - timedelta(days=day)
            start_time = end_time - timedelta(hours=24)

            df = self.db.fetch_data_range(start_time, end_time)

            if df.empty:
                continue

            # Calculer PSI
            psi_result = self.stat_tests.population_stability_index(
                column,
                df[column].values
            )

            psi_values.append(psi_result['psi_value'])

        # Vérifier si tous les jours dépassent le seuil
        threshold = self.triggers['psi_threshold']
        all_above_threshold = all(psi >= threshold for psi in psi_values)

        trigger_activated = all_above_threshold and len(psi_values) >= consecutive_days

        result = {
            'trigger': 'psi',
            'column': column,
            'consecutive_days_checked': len(psi_values),
            'psi_values': psi_values,
            'threshold': threshold,
            'trigger_activated': trigger_activated,
            'timestamp': datetime.now().isoformat()
        }

        if trigger_activated:
            print(f"  🚨 DÉCLENCHEUR PSI ACTIVÉ!")
            print(f"     PSI moyen: {np.mean(psi_values):.3f} (seuil: {threshold})")
        else:
            print(f"  ✅ PSI dans les limites")

        return result

    def check_performance_trigger(self, model_type='g4'):
        """
        Vérifie si la performance du modèle a chuté.

        Args:
            model_type (str): 'g3' ou 'g4'

        Returns:
            dict: Résultat de la vérification
        """
        print(f"\n🔍 Vérification performance ({model_type.upper()})...")

        # Charger l'historique des métriques
        metrics_file = get_monitoring_path('model_metrics_history.json')

        if not os.path.exists(metrics_file):
            print("  ⚠️  Pas d'historique de métriques")
            return {'trigger_activated': False, 'error': 'Pas d\'historique'}

        with open(metrics_file, 'r') as f:
            history = json.load(f)

        # Récupérer les métriques
        if model_type == 'g3':
            metrics_history = history.get('g3_clustering', [])
            metric_key = 'silhouette_score'
        else:  # g4
            metrics_history = history.get('g4_anomaly_detection', [])
            metric_key = 'precision'

        if len(metrics_history) < 2:
            print("  ⚠️  Pas assez d'historique")
            return {'trigger_activated': False, 'error': 'Pas assez d\'historique'}

        # Comparer baseline vs actuel
        baseline = metrics_history[0]['metrics'][metric_key]
        current = metrics_history[-1]['metrics'][metric_key]

        # Calculer la baisse
        drop = baseline - current
        drop_pct = (drop / baseline) * 100

        threshold_pct = self.triggers['performance_drop_threshold'] * 100
        trigger_activated = drop_pct >= threshold_pct

        result = {
            'trigger': 'performance_drop',
            'model_type': model_type,
            'metric': metric_key,
            'baseline_value': baseline,
            'current_value': current,
            'drop_percentage': round(drop_pct, 2),
            'threshold_percentage': threshold_pct,
            'trigger_activated': trigger_activated,
            'timestamp': datetime.now().isoformat()
        }

        if trigger_activated:
            print(f"  🚨 DÉCLENCHEUR PERFORMANCE ACTIVÉ!")
            print(f"     Baisse: {drop_pct:.2f}% (seuil: {threshold_pct}%)")
        else:
            print(f"  ✅ Performance acceptable")

        return result

    def check_anomaly_rate_trigger(self, window_days=7):
        """
        Vérifie si le taux d'anomalies a changé significativement.

        Args:
            window_days (int): Fenêtre d'observation

        Returns:
            dict: Résultat de la vérification
        """
        print(f"\n🔍 Vérification taux d'anomalies...")

        # Récupérer données récentes
        recent_df = self.db.fetch_recent_data(hours=window_days * 24)

        # Récupérer données de référence (même durée, mais il y a 30 jours)
        reference_end = datetime.now() - timedelta(days=30)
        reference_start = reference_end - timedelta(days=window_days)
        reference_df = self.db.fetch_data_range(reference_start, reference_end)

        if recent_df.empty or reference_df.empty:
            print("  ⚠️  Données insuffisantes")
            return {'trigger_activated': False, 'error': 'Données insuffisantes'}

        # Simuler le taux d'anomalies (dans un vrai système, viendrait de G4)
        # Utiliser les valeurs extrêmes comme proxy
        def calculate_anomaly_rate(df):
            power = df['global_active_power']
            q1, q3 = power.quantile([0.05, 0.95])
            anomalies = ((power < q1) | (power > q3)).sum()
            return anomalies / len(df)

        recent_rate = calculate_anomaly_rate(recent_df)
        reference_rate = calculate_anomaly_rate(reference_df)

        # Calculer le changement
        change = abs(recent_rate - reference_rate)
        change_pct = (change / reference_rate) * 100 if reference_rate > 0 else 0

        threshold_pct = self.triggers['anomaly_rate_change'] * 100
        trigger_activated = change_pct >= threshold_pct

        result = {
            'trigger': 'anomaly_rate_change',
            'window_days': window_days,
            'reference_rate': round(reference_rate, 4),
            'recent_rate': round(recent_rate, 4),
            'change_percentage': round(change_pct, 2),
            'threshold_percentage': threshold_pct,
            'trigger_activated': trigger_activated,
            'timestamp': datetime.now().isoformat()
        }

        if trigger_activated:
            print(f"  🚨 DÉCLENCHEUR TAUX ANOMALIES ACTIVÉ!")
            print(f"     Changement: {change_pct:.2f}% (seuil: {threshold_pct}%)")
        else:
            print(f"  ✅ Taux d'anomalies stable")

        return result

    def evaluate_retraining_necessity(self):
        """
        Évalue si un ré-entraînement est nécessaire.

        Returns:
            dict: Décision de ré-entraînement
        """
        print("\n" + "=" * 60)
        print("🎯 ÉVALUATION NÉCESSITÉ RÉ-ENTRAÎNEMENT")
        print("=" * 60)

        triggers_results = []

        # 1. Vérifier PSI
        psi_result = self.check_psi_trigger(
            consecutive_days=self.triggers['drift_duration_days']
        )
        triggers_results.append(psi_result)

        # 2. Vérifier performance G4
        perf_g4_result = self.check_performance_trigger(model_type='g4')
        triggers_results.append(perf_g4_result)

        # 3. Vérifier performance G3
        perf_g3_result = self.check_performance_trigger(model_type='g3')
        triggers_results.append(perf_g3_result)

        # 4. Vérifier taux d'anomalies
        anomaly_rate_result = self.check_anomaly_rate_trigger()
        triggers_results.append(anomaly_rate_result)

        # Décision finale
        any_trigger_activated = any(
            result.get('trigger_activated', False)
            for result in triggers_results
        )

        decision = {
            'timestamp': datetime.now().isoformat(),
            'retraining_recommended': any_trigger_activated,
            'triggers_checked': triggers_results,
            'activated_triggers': [
                result['trigger']
                for result in triggers_results
                if result.get('trigger_activated', False)
            ]
        }

        print("\n" + "=" * 60)
        if any_trigger_activated:
            print("🚨 RÉ-ENTRAÎNEMENT RECOMMANDÉ")
            print(f"   Déclencheurs activés: {', '.join(decision['activated_triggers'])}")
        else:
            print("✅ PAS DE RÉ-ENTRAÎNEMENT NÉCESSAIRE")
        print("=" * 60)

        return decision

    def plan_retraining(self):
        """
        Planifie le ré-entraînement des modèles.

        Returns:
            dict: Plan de ré-entraînement
        """
        print("\n📋 Planification du ré-entraînement...")

        # Paramètres
        rolling_window = self.retraining_params['rolling_window_days']
        min_data_size = self.retraining_params['min_data_size']

        # Récupérer les données pour le ré-entraînement
        df = self.db.fetch_recent_data(hours=rolling_window * 24)

        if len(df) < min_data_size:
            print(f"  ⚠️  Pas assez de données ({len(df)} < {min_data_size})")
            return {'error': 'Données insuffisantes'}

        # Plan de ré-entraînement
        plan = {
            'timestamp': datetime.now().isoformat(),
            'data_collection': {
                'rolling_window_days': rolling_window,
                'samples_available': len(df),
                'min_required': min_data_size,
                'status': 'OK'
            },
            'preprocessing': {
                'steps': [
                    'Nettoyage des valeurs manquantes',
                    'Normalisation avec scaler existant',
                    'Transformation PCA'
                ]
            },
            'models_to_retrain': [],
            'validation': {
                'split_ratio': self.retraining_params['validation_split'],
                'metrics_to_track': []
            },
            'deployment': {
                'rollback_enabled': True,
                'A_B_testing': True
            }
        }

        # Décider quels modèles ré-entraîner
        decision = self.evaluate_retraining_necessity()

        if 'psi' in decision['activated_triggers'] or 'performance_drop' in decision['activated_triggers']:
            if 'g3' in str(decision['triggers_checked']):
                plan['models_to_retrain'].append({
                    'model': 'G3_Clustering',
                    'algorithm': 'DBSCAN',
                    'hyperparameters_to_tune': ['eps', 'min_samples']
                })
                plan['validation']['metrics_to_track'].append('silhouette_score')

        if 'performance_drop' in decision['activated_triggers'] or 'anomaly_rate_change' in decision[
            'activated_triggers']:
            plan['models_to_retrain'].append({
                'model': 'G4_Anomaly_Detection',
                'algorithm': 'Isolation Forest',
                'hyperparameters_to_tune': ['contamination', 'n_estimators']
            })
            plan['validation']['metrics_to_track'].extend(['precision', 'recall', 'f1_score'])

        print(f"  📊 Données disponibles: {len(df)} lignes")
        print(f"  🔧 Modèles à ré-entraîner: {len(plan['models_to_retrain'])}")

        for model in plan['models_to_retrain']:
            print(f"     - {model['model']}")

        return plan

    def execute_retraining_simulation(self):
        """
        Simule l'exécution du ré-entraînement (pour démo).

        Returns:
            dict: Résultats de la simulation
        """
        print("\n🔄 Simulation du ré-entraînement...")

        # Dans un vrai système, cela appellerait les scripts de G3 et G4
        simulation_result = {
            'timestamp': datetime.now().isoformat(),
            'status': 'SIMULATION',
            'steps_executed': [
                {
                    'step': '1. Extraction données',
                    'status': 'OK',
                    'duration_seconds': 15
                },
                {
                    'step': '2. Prétraitement',
                    'status': 'OK',
                    'duration_seconds': 8
                },
                {
                    'step': '3. Ré-entraînement G3',
                    'status': 'OK',
                    'duration_seconds': 45,
                    'new_silhouette_score': 0.42
                },
                {
                    'step': '4. Ré-entraînement G4',
                    'status': 'OK',
                    'duration_seconds': 60,
                    'new_precision': 0.87
                },
                {
                    'step': '5. Validation',
                    'status': 'OK',
                    'duration_seconds': 20
                },
                {
                    'step': '6. Déploiement',
                    'status': 'PENDING',
                    'note': 'Nécessite validation manuelle'
                }
            ],
            'total_duration_minutes': 2.5,
            'recommendation': 'Déployer les nouveaux modèles'
        }

        print("  ✅ Simulation terminée")
        print(f"  ⏱️  Durée totale: {simulation_result['total_duration_minutes']} minutes")

        return simulation_result

    def save_retraining_log(self, decision, plan):
        """
        Sauvegarde le log de ré-entraînement.

        Args:
            decision (dict): Décision de ré-entraînement
            plan (dict): Plan de ré-entraînement
        """
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'decision': decision,
            'plan': plan
        }

        self.retraining_history.append(log_entry)

        # Sauvegarder dans un fichier
        log_file = get_monitoring_path('retraining_logs.json')

        # Charger historique existant
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                history = json.load(f)
        else:
            history = []

        history.append(log_entry)

        with open(log_file, 'w') as f:
            json.dump(history, f, indent=2)

        print(f"\n💾 Log sauvegardé: {log_file}")

    def generate_retraining_report(self):
        """
        Génère un rapport complet de stratégie de ré-entraînement.

        Returns:
            dict: Rapport complet
        """
        print("\n" + "=" * 60)
        print("📋 RAPPORT DE STRATÉGIE DE RÉ-ENTRAÎNEMENT")
        print("=" * 60)

        # Évaluer la nécessité
        decision = self.evaluate_retraining_necessity()

        # Planifier si nécessaire
        if decision['retraining_recommended']:
            plan = self.plan_retraining()
            simulation = self.execute_retraining_simulation()
        else:
            plan = None
            simulation = None

        # Sauvegarder le log
        self.save_retraining_log(decision, plan)

        report = {
            'timestamp': datetime.now().isoformat(),
            'decision': decision,
            'plan': plan,
            'simulation': simulation
        }

        print("\n" + "=" * 60)
        print("✅ Rapport de stratégie généré")
        print("=" * 60)

        return report


def execute_retraining(self):
    """
    Exécute le processus complet de ré-entraînement.

    Étapes:
    1. Extraction nouvelles données
    2. Validation qualité données
    3. Déclenchement ré-entraînement G3
    4. Déclenchement ré-entraînement G4
    5. Validation performance
    6. Mise à jour modèles si amélioration
    """
    logger.info("🔄 DÉMARRAGE RÉ-ENTRAÎNEMENT")

    # 1. Extraction données
    rolling_days = self.retraining_params['rolling_window_days']
    end_date = datetime.now()
    start_date = end_date - timedelta(days=rolling_days)

    new_data = self.db.fetch_data_range(start_date, end_date)

    if len(new_data) < self.retraining_params['min_data_size']:
        logger.warning(f"Données insuffisantes: {len(new_data)} < {self.retraining_params['min_data_size']}")
        return False

    # 2-6. Appeler scripts G3 et G4
    # (À implémenter selon architecture G3/G4)

    logger.info("✅ Ré-entraînement terminé")
    return True

def main():
    """Point d'entrée principal."""
    strategy = RetrainingStrategy()
    strategy.generate_retraining_report()


if __name__ == "__main__":
    main()